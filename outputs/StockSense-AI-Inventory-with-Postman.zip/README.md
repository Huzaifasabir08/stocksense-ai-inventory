# StockSense: AI Inventory for a Shopping Mall

Full-stack local inventory application for Nowshera Shopping Mall.

## Start

Run `python app.py`, then open `http://127.0.0.1:8765`.

Manager: `manager@stocksense.local` / `manager123`

Staff: `staff@stocksense.local` / `staff123`

The SQLite database is created automatically as `stocksense.db`. Set `AI_DISABLED=1` before starting to demonstrate the AI failure state; normal inventory pages and forms remain available.

## Validation

Run `python test_acceptance.py` to validate grounded answers, confirmation safety, negative-stock protection, staff privacy, and AI failure resilience.
