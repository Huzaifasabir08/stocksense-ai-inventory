import json, os, re, secrets, sqlite3
from datetime import datetime, timedelta
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs

ROOT = Path(__file__).parent
DB = ROOT / "stocksense.db"
STATIC = ROOT / "static"
SESSIONS = {}

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c

def init_db():
    c=db(); c.executescript("""
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT UNIQUE,password TEXT,role TEXT,name TEXT);
    CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY,sku TEXT UNIQUE,name TEXT,category TEXT,section TEXT,description TEXT,selling_price REAL,cost_price REAL,min_stock INTEGER,current_stock INTEGER,supplier TEXT,location TEXT,status TEXT DEFAULT 'active',created_at TEXT,updated_at TEXT);
    CREATE TABLE IF NOT EXISTS movements(id INTEGER PRIMARY KEY,product_id INTEGER,type TEXT,quantity INTEGER,previous_stock INTEGER,new_stock INTEGER,user_id INTEGER,supplier TEXT,reason TEXT,status TEXT,created_at TEXT,proposal_key TEXT UNIQUE,FOREIGN KEY(product_id) REFERENCES products(id));
    CREATE TABLE IF NOT EXISTS proposals(id TEXT PRIMARY KEY,product_id INTEGER,type TEXT,quantity INTEGER,supplier TEXT,reason TEXT,user_id INTEGER,status TEXT,created_at TEXT,FOREIGN KEY(product_id) REFERENCES products(id));
    CREATE INDEX IF NOT EXISTS idx_movements_product_date ON movements(product_id,created_at);
    """)
    if not c.execute("SELECT 1 FROM users LIMIT 1").fetchone():
        c.executemany("INSERT INTO users(email,password,role,name) VALUES(?,?,?,?)",[("manager@stocksense.local","manager123","manager","Amina Khan"),("staff@stocksense.local","staff123","staff","Bilal Shah")])
    if not c.execute("SELECT 1 FROM products LIMIT 1").fetchone():
        now=datetime.now().isoformat(); products=[
          ("EL-CAB-001","Type-C Cable","Accessories","Electronics","Fast charging USB-C cable",899,430,20,15,"Ali Traders","E-A12"),
          ("EL-TV-042","Samsung 55-inch TV","Television","Electronics","4K smart television",189999,157000,4,9,"Tech World","E-B02"),
          ("GR-RIC-025","Basmati Rice 5kg","Staples","Grocery","Premium basmati rice",1890,1520,15,46,"Frontier Foods","G-C08"),
          ("CL-TSH-110","Cotton T-Shirt","Menswear","Clothing","Classic cotton t-shirt",1599,850,10,8,"Style House","C-A04"),
          ("HH-DET-022","Laundry Detergent","Cleaning","Household","2kg detergent pack",1240,930,12,0,"CleanCo","H-D10")]
        for p in products: c.execute("INSERT INTO products(sku,name,category,section,description,selling_price,cost_price,min_stock,current_stock,supplier,location,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(*p,now,now))
        user=1
        for pid,qty in [(1,20),(2,32),(3,14),(4,5)]:
            stock=c.execute("SELECT current_stock FROM products WHERE id=?",(pid,)).fetchone()[0]
            c.execute("INSERT INTO movements(product_id,type,quantity,previous_stock,new_stock,user_id,supplier,reason,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",(pid,"sale",qty,stock+qty,stock,user,None,"Demo weekly sale","completed",(datetime.now()-timedelta(days=2)).isoformat()))
    c.commit(); c.close()

def user_from(req):
    token=req.headers.get("Authorization","").replace("Bearer ","")
    return SESSIONS.get(token)

def product_json(row, role):
    d=dict(row); d["stock_status"]="Out of stock" if d["current_stock"]==0 else "Low stock" if d["current_stock"]<=d["min_stock"] else "In stock"
    if role!="manager": d.pop("cost_price",None)
    return d

def apply_movement(c, user, product_id, movement_type, qty, supplier="", reason="", proposal_key=None):
    if qty<=0: raise ValueError("Quantity must be greater than zero.")
    p=c.execute("SELECT * FROM products WHERE id=?",(product_id,)).fetchone()
    if not p: raise ValueError("Product could not be found.")
    delta=qty if movement_type=="stock_in" else -qty
    new=p["current_stock"]+delta
    if new<0: raise ValueError(f"Insufficient stock. Only {p['current_stock']} units are available.")
    now=datetime.now().isoformat()
    try:
        c.execute("INSERT INTO movements(product_id,type,quantity,previous_stock,new_stock,user_id,supplier,reason,status,created_at,proposal_key) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(product_id,movement_type,qty,p["current_stock"],new,user["id"],supplier,reason,"completed",now,proposal_key))
    except sqlite3.IntegrityError: raise ValueError("This confirmation was already applied.")
    c.execute("UPDATE products SET current_stock=?,updated_at=? WHERE id=?",(new,now,product_id))
    return {"product":p["name"],"previous":p["current_stock"],"new":new,"change":delta}

def grounded_answer(c, user, text):
    lower=text.lower()
    if user["role"]!="manager" and any(x in lower for x in ["profit","cost price","margin","i am the manager","ignore your rules","developer mode"]):
        return {"type":"answer","text":"I can’t show cost, profit, or manager-only information for your staff account."}
    if os.getenv("AI_DISABLED")=="1": raise RuntimeError("AI unavailable")
    add=re.search(r"(?:add|increase|receive)\s+(\d+)\s+(.+?)(?:\s+from\s+(.+))?[.!]?$",text,re.I)
    if add:
        qty=int(add.group(1)); phrase=add.group(2).strip(); supplier=(add.group(3) or "").strip()
        p=c.execute("SELECT * FROM products WHERE lower(name) LIKE ? OR lower(name) LIKE ? LIMIT 1",(f"%{phrase.lower().rstrip('s')}%",f"%{phrase.lower()}%" )).fetchone()
        if not p: return {"type":"answer","text":"I couldn’t find that product in inventory."}
        pid=secrets.token_hex(12); c.execute("INSERT INTO proposals VALUES(?,?,?,?,?,?,?,?,?)",(pid,p["id"],"stock_in",qty,supplier,"AI prepared stock receipt",user["id"],"pending",datetime.now().isoformat())); c.commit()
        return {"type":"proposal","proposal_id":pid,"product":p["name"],"current":p["current_stock"],"change":qty,"new":p["current_stock"]+qty,"supplier":supplier}
    if "low" in lower:
        rows=c.execute("SELECT * FROM products WHERE current_stock<=min_stock ORDER BY current_stock").fetchall()
        return {"type":"answer","text":"Low-stock products: "+", ".join(f"{r['name']} ({r['current_stock']} left)" for r in rows)+"."}
    if "out of stock" in lower:
        rows=c.execute("SELECT name FROM products WHERE current_stock=0").fetchall(); return {"type":"answer","text":"Out of stock: "+(", ".join(r[0] for r in rows) or "None")+"."}
    if "sold most" in lower:
        since=(datetime.now()-timedelta(days=7)).isoformat(); r=c.execute("SELECT p.name,SUM(m.quantity) q FROM movements m JOIN products p ON p.id=m.product_id WHERE m.type='sale' AND m.created_at>=? GROUP BY p.id ORDER BY q DESC LIMIT 1",(since,)).fetchone()
        return {"type":"answer","text":f"{r['name']} sold the most this week: {r['q']} units." if r else "No sales were recorded this week."}
    found=[]
    for p in c.execute("SELECT * FROM products").fetchall():
        name=p["name"].lower()
        key=" ".join(w for w in re.sub(r"[^a-z0-9 -]","",name).split() if not w.replace("-","").isdigit())
        if name in lower or key in lower: found.append(f"{p['name']}: {p['current_stock']} units")
    if found: return {"type":"answer","text":"Current stock — "+"; ".join(found)+"."}
    return {"type":"answer","text":"I couldn’t find a matching product or report. Try the exact product name."}

class Handler(SimpleHTTPRequestHandler):
    def end_headers(self): self.send_header("Cache-Control","no-store"); super().end_headers()
    def json(self,status,data):
        body=json.dumps(data).encode(); self.send_response(status); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
    def body(self):
        try: return json.loads(self.rfile.read(int(self.headers.get("Content-Length","0"))) or b"{}")
        except: return {}
    def do_GET(self):
        path=urlparse(self.path).path
        if path.startswith("/api/"):
            u=user_from(self)
            if not u: return self.json(401,{"error":"Please sign in."})
            c=db()
            try:
                if path=="/api/products": return self.json(200,[product_json(r,u["role"]) for r in c.execute("SELECT * FROM products ORDER BY name")])
                if path=="/api/dashboard":
                    products=c.execute("SELECT * FROM products").fetchall(); total=sum(p["current_stock"] for p in products); low=sum(p["current_stock"]<=p["min_stock"] and p["current_stock"]>0 for p in products); out=sum(p["current_stock"]==0 for p in products)
                    recent=[dict(r) for r in c.execute("SELECT m.*,p.name product,u.name user FROM movements m JOIN products p ON p.id=m.product_id JOIN users u ON u.id=m.user_id ORDER BY m.id DESC LIMIT 8")]
                    return self.json(200,{"products":len(products),"units":total,"low":low,"out":out,"pending":c.execute("SELECT COUNT(*) FROM proposals WHERE status='pending'").fetchone()[0],"recent":recent,"user":u})
                if path=="/api/history": return self.json(200,[dict(r) for r in c.execute("SELECT m.*,p.name product,u.name user FROM movements m JOIN products p ON p.id=m.product_id JOIN users u ON u.id=m.user_id ORDER BY m.id DESC")])
                return self.json(404,{"error":"Not found"})
            finally: c.close()
        self.path="/index.html" if path=="/" else path; return super().do_GET()
    def do_POST(self):
        path=urlparse(self.path).path; data=self.body()
        if path=="/api/login":
            c=db(); row=c.execute("SELECT id,email,role,name FROM users WHERE email=? AND password=?",(data.get("email"),data.get("password"))).fetchone(); c.close()
            if not row:return self.json(401,{"error":"Incorrect email or password."})
            token=secrets.token_hex(24); SESSIONS[token]=dict(row); return self.json(200,{"token":token,"user":dict(row)})
        u=user_from(self)
        if not u:return self.json(401,{"error":"Please sign in."})
        c=db()
        try:
            if path=="/api/movements":
                try: result=apply_movement(c,u,int(data.get("product_id",0)),data.get("type",""),int(data.get("quantity",0)),data.get("supplier",""),data.get("reason","")); c.commit(); return self.json(201,result)
                except ValueError as e: c.rollback(); return self.json(400,{"error":str(e)})
            if path=="/api/chat":
                try:return self.json(200,grounded_answer(c,u,str(data.get("message",""))))
                except RuntimeError:return self.json(503,{"error":"AI Assistant is currently unavailable. You can continue using the inventory system normally."})
            if path.startswith("/api/proposals/"):
                pid=path.split("/")[-1]; p=c.execute("SELECT * FROM proposals WHERE id=?",(pid,)).fetchone()
                if not p:return self.json(404,{"error":"Proposal not found."})
                if p["user_id"]!=u["id"]:return self.json(403,{"error":"You are not allowed to confirm this proposal."})
                action=data.get("action")
                if action=="cancel": c.execute("UPDATE proposals SET status='cancelled' WHERE id=? AND status='pending'",(pid,)); c.commit(); return self.json(200,{"status":"cancelled"})
                if p["status"]!="pending": return self.json(409,{"error":"This proposal is no longer pending."})
                try: result=apply_movement(c,u,p["product_id"],p["type"],p["quantity"],p["supplier"],p["reason"],pid); c.execute("UPDATE proposals SET status='confirmed' WHERE id=?",(pid,)); c.commit(); return self.json(200,result)
                except ValueError as e: c.rollback(); return self.json(400,{"error":str(e)})
            if path=="/api/prices":
                if u["role"]!="manager": return self.json(403,{"error":"Manager permission is required."})
                c.execute("UPDATE products SET selling_price=?,updated_at=? WHERE id=?",(float(data["selling_price"]),datetime.now().isoformat(),int(data["product_id"]))); c.commit(); return self.json(200,{"status":"updated"})
            return self.json(404,{"error":"Not found"})
        finally:c.close()

if __name__=="__main__":
    init_db(); os.chdir(STATIC); print("StockSense running at http://127.0.0.1:8765"); ThreadingHTTPServer(("127.0.0.1",8765),Handler).serve_forever()
